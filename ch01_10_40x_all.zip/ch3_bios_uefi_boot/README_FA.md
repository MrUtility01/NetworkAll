# فصل 3 — BIOS، UEFI و فرآیند بوت

# فصل 3 — BIOS، UEFI و فرآیند بوت — عمق 40x

| سهمیه | تعداد |
|-------|--------|
| lessons | 500 |
| questions | 500 |
| answers | 500 |
| labs | 100 |
| examples | 100 |

UID d40 | preserve_existing | review_required
