# فصل ۶۸ — دانشنامه دستورات (همه حوزه‌ها)

وضعیت: review_required

## جمع دستورات: 3600

| حوزه | تعداد | فایل |
|------|--------|------|
| سیسکو IOS-XE (cisco) | 500 | commands_cisco.json |
| داکر (docker) | 300 | commands_docker.json |
| فورتی‌گیت FortiOS (fortigate) | 500 | commands_fortigate.json |
| لینوکس (linux) | 500 | commands_linux.json |
| میکروتیک RouterOS (mikrotik) | 500 | commands_mikrotik.json |
| ویندوز PowerShell و CMD (windows) | 500 | commands_windows.json |
| ویندوز Batch/CMD (windows_batch) | 500 | commands_windows_batch.json |
| ویندوز سرور / Active Directory (windows_server) | 300 | commands_windows_server.json |

| آزمون کاربرد دستور | 1120 | questions_commands_usage.json |

## ساختار هر رکورد
uid, vendor, platform, category, subcategory, command, when_to_use_fa,
steps, flashcards, assessment (دستور→کاربرد)

## ادغام
فایل‌ها را در tools/chapters/68/commands/sources/ بگذارید یا با apply pack ادغام کنید.
UIDهای قبلی commands.json را حذف نکنید.
